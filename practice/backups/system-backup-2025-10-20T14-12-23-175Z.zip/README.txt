Room Reservation System Backup
===============================

Backup created: 2025-10-20T14:12:23.180Z
Format: ZIP Archive
Compression: High

CONTENTS:
---------
/README.txt           - This file
/backup-metadata.json - Backup information and collection list
/database-stats.json  - Database statistics
/collections/         - Complete collections as JSON files

RESTORATION:
------------
1. Extract this ZIP file
2. Use the JSON files in /collections/ for data restoration
3. Refer to backup-metadata.json for collection information

NOTES:
------
- This is a complete database backup
- All timestamps are in ISO format
- Collections are stored as complete JSON files
- This backup contains all non-system collections
